// SPDX-License-Identifier: MIT
pragma solidity ^0.8.33;

contract ViewPureDemo {
    uint256 public data = 42;
    string public message = "Blockchain";
    
    // TODO: Create a VIEW function that returns 'data'
    // - Name: getData()
    // - Visibility: public
    // - Returns: uint256
    // - Modifier: view
    // _________________________________________________
    // _________________________________________________
    // _________________________________________________

    // TODO: Create a VIEW function that returns LENGTH of 'message'
    // - Name: getMessageLength()
    // - Visibility: public
    // - Returns: uint256
    // - Modifier: view
    // Hint: bytes(message).length
    // _________________________________________________
    // _________________________________________________
    // _________________________________________________

    // TODO: Create a PURE function that adds two numbers
    // - Name: add(uint256 a, uint256 b)
    // - Visibility: public
    // - Returns: uint256
    // - Modifier: pure
    // _________________________________________________
    // _________________________________________________
    // _________________________________________________

    // TODO: Create a PURE function that concatenates two strings
    // - Name: concatenate(string memory a, string memory b)
    // - Visibility: public
    // - Returns: string memory
    // - Modifier: pure
    // Hint: string(abi.encodePacked(a, b))
    // _________________________________________________
    // _________________________________________________
    // _________________________________________________
}

contract Setup {
    ViewPureDemo public demo;
    
    constructor() {
        demo = new ViewPureDemo();
    }
    
    function isSolved() external view returns (bool) {
        return demo.getData() == 42 &&
               demo.getMessageLength() == 10 &&
               demo.add(5, 7) == 12 &&
               keccak256(bytes(demo.concatenate("Hello", "World"))) == keccak256(bytes("HelloWorld"));
    }
}