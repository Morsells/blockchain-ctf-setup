// SPDX-License-Identifier: MIT
pragma solidity ^0.8.23;

/*
    CHALLENGE: B4_msg_context

    Learning goals:
    - Understand msg.sender
    - Difference between EOAs and contracts
    - Why ETH transfers can fail
    - Who actually receives Ether in withdraw()
*/

contract SimpleBank {
    mapping(address => uint256) public balances;

    /// @notice Deposit Ether into the bank
    function deposit() external payable {
        require(msg.value > 0, "Must send ether");

        // TODO:
        // Increase the balance of msg.sender
        balances[msg.sender] += msg.value;
    }

    /// @notice Withdraw Ether from the bank
    function withdraw(uint256 amount) external {
        // TODO:
        // Ensure msg.sender has enough balance
        require(balances[msg.sender] >= amount, "Insufficient balance");

        // TODO:
        // Update state BEFORE sending Ether
        balances[msg.sender] -= amount;

        // TODO:
        // Send Ether to msg.sender
        // Hint: transfer() and send() are deprecated
        (bool success, ) = payable(msg.sender).call{value: amount}("");
        require(success, "Transfer failed");
    }

    function getBalance(address user) external view returns (uint256) {
        return balances[user];
    }
}

/*
    SETUP CONTRACT

    Important:
    - This contract is NOT the player
    - It interacts with the bank on deployment
*/
contract Setup {
    SimpleBank public bank;
    uint256 public constant TREASURY = 1 ether;

    constructor() payable {
        require(msg.value == TREASURY, "need 1 ether");

        bank = new SimpleBank();

        // TODO:
        // Deposit 1 ether from Setup into the bank
        bank.deposit{value: TREASURY}();
    }

    // TODO:
    // Why is this function required?
    // Hint: What happens if the bank sends Ether to this contract?
    receive() external payable {}

    /*
        The challenge is solved when:
        - the bank is empty
        - the player owns at least 1 ether
    */
    function isSolved(address player) external view returns (bool) {
        return address(bank).balance == 0 && player.balance >= TREASURY;
    }
}
