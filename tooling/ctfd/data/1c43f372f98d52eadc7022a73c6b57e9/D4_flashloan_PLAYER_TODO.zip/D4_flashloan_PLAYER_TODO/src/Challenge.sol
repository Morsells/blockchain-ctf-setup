// SPDX-License-Identifier: MIT
pragma solidity ^0.8.23;

contract TokenA {
    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;

    function mintForTraining(address to, uint256 amount) external {
        balanceOf[to] += amount;
    }

    function approve(address spender, uint256 amount) external returns (bool) {
        allowance[msg.sender][spender] = amount;
        return true;
    }

    function transfer(address to, uint256 amount) external returns (bool) {
        require(balanceOf[msg.sender] >= amount, "no balance");
        balanceOf[msg.sender] -= amount;
        balanceOf[to] += amount;
        return true;
    }

    function transferFrom(address from, address to, uint256 amount) external returns (bool) {
        require(balanceOf[from] >= amount, "no balance");
        require(allowance[from][msg.sender] >= amount, "no allowance");
        allowance[from][msg.sender] -= amount;
        balanceOf[from] -= amount;
        balanceOf[to] += amount;
        return true;
    }
}

contract TokenB {
    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;

    function mintForTraining(address to, uint256 amount) external {
        balanceOf[to] += amount;
    }

    function approve(address spender, uint256 amount) external returns (bool) {
        allowance[msg.sender][spender] = amount;
        return true;
    }

    function transfer(address to, uint256 amount) external returns (bool) {
        require(balanceOf[msg.sender] >= amount, "no balance");
        balanceOf[msg.sender] -= amount;
        balanceOf[to] += amount;
        return true;
    }

    function transferFrom(address from, address to, uint256 amount) external returns (bool) {
        require(balanceOf[from] >= amount, "no balance");
        require(allowance[from][msg.sender] >= amount, "no allowance");
        allowance[from][msg.sender] -= amount;
        balanceOf[from] -= amount;
        balanceOf[to] += amount;
        return true;
    }
}

contract SimpleAMM {
    uint256 public constant BPS = 10_000;
    uint256 public constant FEE_BPS = 30;

    TokenA public tokenA;
    TokenB public tokenB;
    uint256 public reserveA;
    uint256 public reserveB;

    constructor(TokenA a, TokenB b, uint256 initA, uint256 initB) {
        tokenA = a;
        tokenB = b;
        tokenA.mintForTraining(address(this), initA);
        tokenB.mintForTraining(address(this), initB);
        reserveA = initA;
        reserveB = initB;
    }

    function spotPriceAinB() external view returns (uint256) {
        require(reserveA > 0, "no A");
        return (reserveB * 1e18) / reserveA;
    }

    function getAmountOut(uint256 amountIn, uint256 reserveIn, uint256 reserveOut) public pure returns (uint256) {
        uint256 amountInWithFee = (amountIn * (BPS - FEE_BPS)) / BPS;
        return (amountInWithFee * reserveOut) / (reserveIn + amountInWithFee);
    }

    function swapBforA(uint256 amountIn) external returns (uint256 out) {
        require(tokenB.transferFrom(msg.sender, address(this), amountIn), "b in");
        out = getAmountOut(amountIn, reserveB, reserveA);
        reserveB += amountIn;
        reserveA -= out;
        require(tokenA.transfer(msg.sender, out), "a out");
    }

    function swapAforB(uint256 amountIn) external returns (uint256 out) {
        require(tokenA.transferFrom(msg.sender, address(this), amountIn), "a in");
        out = getAmountOut(amountIn, reserveA, reserveB);
        reserveA += amountIn;
        reserveB -= out;
        require(tokenB.transfer(msg.sender, out), "b out");
    }
}

contract SimpleOracle {
    SimpleAMM public amm;

    constructor(SimpleAMM _amm) {
        amm = _amm;
    }

    function priceAinB() external view returns (uint256) {
        return amm.spotPriceAinB();
    }
}

contract LendingPool {
    SimpleOracle public oracle;
    TokenA public tokenA;
    TokenB public tokenB;

    uint256 public constant LTV_BPS = 5000;
    uint256 public constant BPS = 10_000;

    mapping(address => uint256) public collA;
    mapping(address => uint256) public debtB;

    constructor(SimpleOracle o, TokenA a, TokenB b, uint256 seedB) {
        oracle = o;
        tokenA = a;
        tokenB = b;
        tokenB.mintForTraining(address(this), seedB);
    }

    function depositA(uint256 amount) external {
        require(amount > 0, "bad amount");
        require(tokenA.transferFrom(msg.sender, address(this), amount), "transfer A");
        collA[msg.sender] += amount;
    }

    function maxBorrow(address user) public view returns (uint256) {
        uint256 price = oracle.priceAinB();
        uint256 value = (collA[user] * price) / 1e18;
        return (value * LTV_BPS) / BPS;
    }

    function borrowB(uint256 amount) external {
        require(amount > 0, "bad amount");
        uint256 newDebt = debtB[msg.sender] + amount;
        require(maxBorrow(msg.sender) >= newDebt, "bad collateral");
        require(tokenB.balanceOf(address(this)) >= amount, "no liquidity");
        debtB[msg.sender] = newDebt;
        require(tokenB.transfer(msg.sender, amount), "transfer B");
    }
}

interface IFlashBorrower {
    function onFlashLoan(uint256 amount, uint256 fee, bytes calldata data) external returns (bytes32);
}

contract FlashLoanProvider {
    uint256 public constant BPS = 10_000;
    uint256 public constant FEE_BPS = 5;

    TokenB public tokenB;

    constructor(TokenB b, uint256 seed) {
        tokenB = b;
        tokenB.mintForTraining(address(this), seed);
    }

    function fee(uint256 amount) public pure returns (uint256) {
        return (amount * FEE_BPS) / BPS;
    }

    function flash(address borrower, uint256 amount, bytes calldata data) external {
        uint256 start = tokenB.balanceOf(address(this));
        require(start >= amount, "no funds");

        require(tokenB.transfer(borrower, amount), "transfer out");
        uint256 f = fee(amount);

        bytes32 ok = IFlashBorrower(borrower).onFlashLoan(amount, f, data);
        require(ok == keccak256("OK"), "callback");

        require(tokenB.balanceOf(address(this)) >= start + f, "not repaid");
    }
}

contract SetupD4 {
    TokenA public tokenA;
    TokenB public tokenB;
    SimpleAMM public amm;
    SimpleOracle public oracle;
    LendingPool public pool;
    FlashLoanProvider public fl;

    uint256 public startPoolB;
    uint256 public startFlB;

    constructor() {
        tokenA = new TokenA();
        tokenB = new TokenB();
        amm = new SimpleAMM(tokenA, tokenB, 1_000 ether, 2_000 ether);
        oracle = new SimpleOracle(amm);
        pool = new LendingPool(oracle, tokenA, tokenB, 10_000 ether);
        fl = new FlashLoanProvider(tokenB, 5_000 ether);

        startPoolB = tokenB.balanceOf(address(pool));
        startFlB = tokenB.balanceOf(address(fl));
    }

    function isSolved(address player) external view returns (bool) {
        bool flashRepaid = tokenB.balanceOf(address(fl)) >= startFlB + fl.fee(3_000 ether);
        bool poolUsed = tokenB.balanceOf(address(pool)) < startPoolB;
        bool playerProfit = tokenB.balanceOf(player) > 0;
        return flashRepaid && poolUsed && playerProfit;
    }
}
