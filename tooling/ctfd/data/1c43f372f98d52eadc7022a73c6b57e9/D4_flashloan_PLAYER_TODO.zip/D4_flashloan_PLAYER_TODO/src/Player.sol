// SPDX-License-Identifier: MIT
pragma solidity ^0.8.23;

import "./Challenge.sol";

contract Player {
    function solve(SetupD4 setup) external {
        // TODO: Execute flashloan-based flow.
        // TODO: Manipulate AMM/oracle state and borrow from pool.
        // TODO: Repay flashloan + fee and keep profit on this contract.
        setup;
    }
}
