// SPDX-License-Identifier: MIT
pragma solidity ^0.8.23;

contract Counter {
    uint256 public count;
    address public lastCaller;
    
    // TODO: Implementiere increment()
    // - Erhoehe count um 1
    // - Setze lastCaller = msg.sender
    // - Gib count zurueck
    function increment() external returns (uint256) {
        // _________________________________________________
        // _________________________________________________
        // _________________________________________________
    }
    
    // TODO: Gib count zurueck
    function getCount() external view returns (uint256) {
        // _________________________________________________
    }
    
    // TODO: Gib lastCaller zurueck
    function getLastCaller() external view returns (address) {
        // _________________________________________________
    }
}

contract Setup {
    Counter public counter;
    
    // TODO: Erstelle eine neue Counter Instanz
    constructor() {
        // _________________________________________________
    }
    
    // TODO: Gib true zurueck wenn:
    // - count == 3
    // - lastCaller != address(0)
    function isSolved() external view returns (bool) {
        // _________________________________________________
        // _________________________________________________
    }
}