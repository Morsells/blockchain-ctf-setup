// SPDX-License-Identifier: MIT
pragma solidity ^0.8.33;

contract Counter {
    uint256 public counter;
    address public owner;

    constructor() {
        owner = msg.sender;
        counter = 0;
    }

    // TODO: Implementiere eine Funktion, die den Counter um 1 erhöht
    // - Name: increment()
    // - Sichtbarkeit: public
    // - Rückgabewert: keiner
    // - Ändert den State!
    // _________________________________________________
    // _________________________________________________
    // _________________________________________________

    // TODO: Implementiere eine Funktion, die den aktuellen Counter-Wert zurückgibt
    // - Name: getCounter()
    // - Sichtbarkeit: public
    // - Rückgabewert: uint256
    // - view Funktion (ändert keinen State!)
    // _________________________________________________
    // _________________________________________________
    // _________________________________________________
}

contract Setup {
    Counter public counter;

    constructor() {
        counter = new Counter();
    }

    function isSolved() external view returns (bool) {
        // Die Challenge ist gelöst, wenn der Counter 5 mal erhöht wurde
        return counter.counter() == 5;
    }
}