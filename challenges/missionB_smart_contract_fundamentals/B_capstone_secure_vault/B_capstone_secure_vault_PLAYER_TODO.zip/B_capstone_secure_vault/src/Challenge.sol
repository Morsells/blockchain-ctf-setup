// SPDX-License-Identifier: MIT
pragma solidity ^0.8.33;

import "./SimpleToken.sol";

/**
 * @title SecureVault
 * @dev Implementiere einen sicheren Token-Vault
 * 
 * TODO LISTE:
 * 1. Events definieren (Deposited, Withdrawn, Paused, Unpaused)
 * 2. Konstruktor: owner und token setzen
 * 3. onlyOwner Modifier implementieren
 * 4. whenNotPaused Modifier implementieren
 * 5. deposit() Funktion implementieren
 * 6. withdraw() Funktion implementieren
 * 7. getVaultBalance() implementieren
 * 8. getUserBalance() implementieren
 * 9. pause() implementieren
 * 10. unpause() implementieren
 */
contract SecureVault {
    SimpleToken public immutable token;
    address public owner;
    bool public paused;
    
    mapping(address => uint256) private userBalances;
    uint256 public vaultBalance;
    
    // TODO: Definiere Events
    // event Deposited(address indexed user, uint256 amount);
    // event Withdrawn(address indexed user, uint256 amount);
    // event Paused(address indexed by);
    // event Unpaused(address indexed by);
    // _________________________________________________
    // _________________________________________________
    // _________________________________________________
    // _________________________________________________
    
    constructor(address _token) {
        // TODO: Setze owner = msg.sender
        // TODO: Setze token = SimpleToken(_token)
        // TODO: Setze paused = false
        // _________________________________________________
        // _________________________________________________
        // _________________________________________________
    }
    
    // TODO: Implementiere onlyOwner Modifier
    // require(msg.sender == owner, "Not owner");
    // _________________________________________________
    // _________________________________________________
    // _________________________________________________
    
    // TODO: Implementiere whenNotPaused Modifier
    // require(!paused, "Contract paused");
    // _________________________________________________
    // _________________________________________________
    // _________________________________________________
    
    /**
     * @dev Token in den Vault einzahlen
     */
    function deposit(uint256 amount) external whenNotPaused {
        // TODO: Implementiere deposit()
        // 1. require(amount > 0, "Amount must be greater than 0")
        // 2. token.transferFrom(msg.sender, address(this), amount)
        // 3. userBalances[msg.sender] += amount
        // 4. vaultBalance += amount
        // 5. emit Deposited(msg.sender, amount)
        // _________________________________________________
        // _________________________________________________
        // _________________________________________________
        // _________________________________________________
        // _________________________________________________
        // _________________________________________________
    }
    
    /**
     * @dev Token aus dem Vault abheben (nur Owner)
     */
    function withdraw(uint256 amount) external onlyOwner whenNotPaused {
        // TODO: Implementiere withdraw()
        // 1. require(amount > 0, "Amount must be greater than 0")
        // 2. require(vaultBalance >= amount, "Insufficient vault balance")
        // 3. vaultBalance -= amount
        // 4. token.transfer(owner, amount)
        // 5. emit Withdrawn(msg.sender, amount)
        // _________________________________________________
        // _________________________________________________
        // _________________________________________________
        // _________________________________________________
        // _________________________________________________
        // _________________________________________________
    }
    
    /**
     * @dev Aktuelle Balance des gesamten Vaults
     */
    function getVaultBalance() external view returns (uint256) {
        // TODO: Gib vaultBalance zurück
        // _________________________________________________
    }
    
    /**
     * @dev Balance eines bestimmten Users
     */
    function getUserBalance(address user) external view returns (uint256) {
        // TODO: Gib userBalances[user] zurück
        // _________________________________________________
    }
    
    /**
     * @dev Pausiere den Contract (nur Owner)
     */
    function pause() external onlyOwner {
        // TODO: Implementiere pause()
        // 1. require(!paused, "Already paused")
        // 2. paused = true
        // 3. emit Paused(msg.sender)
        // _________________________________________________
        // _________________________________________________
        // _________________________________________________
    }
    
    /**
     * @dev Entpausiere den Contract (nur Owner)
     */
    function unpause() external onlyOwner {
        // TODO: Implementiere unpause()
        // 1. require(paused, "Not paused")
        // 2. paused = false
        // 3. emit Unpaused(msg.sender)
        // _________________________________________________
        // _________________________________________________
        // _________________________________________________
    }
}

/**
 * @title Setup
 * @dev Deployed die Challenge und prüft die Lösung
 */
contract Setup {
    SecureVault public vault;
    SimpleToken public token;
    address public owner;
    
    uint256 public constant INITIAL_SUPPLY = 1000 ether;
    
    constructor() {
        owner = msg.sender;
        token = new SimpleToken(INITIAL_SUPPLY);
        vault = new SecureVault(address(token));
        
        // Owner gibt Token an User für Tests
        token.transfer(address(0x1), 100 ether);
        token.transfer(address(0x2), 100 ether);
    }
    
    function isSolved() external view returns (bool) {
        // Challenge ist gelöst wenn:
        // 1. Vault korrekt funktioniert (wird durch Tests validiert)
        // 2. Alle Tests bestehen
        return address(vault).balance > 0; // Dummy - echte Prüfung in Tests
    }
}