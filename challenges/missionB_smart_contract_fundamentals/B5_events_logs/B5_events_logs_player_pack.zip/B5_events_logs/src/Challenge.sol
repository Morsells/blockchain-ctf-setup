// SPDX-License-Identifier: MIT
pragma solidity ^0.8.23;

/*
    SOLUTION VERSION

    Fixes:
    - Events are emitted ONLY after validation
    - Prevents logging on failed actions
*/

contract Logger {
    event ActionLogged(address indexed user, string message);
    event AdminAction(address indexed admin, string action);

    address public admin;
    bool public systemActive = true;

    constructor() {
        admin = msg.sender;
    }

    function logAction(string memory message) external {
        require(systemActive, "System inactive");

        // Event emitted ONLY if action is valid
        emit ActionLogged(msg.sender, message);

        // Real logic would be here
    }

    function adminLog(string memory action) external {
        require(msg.sender == admin, "Not admin");
        emit AdminAction(msg.sender, action);
    }

    function toggleSystem() external {
        require(msg.sender == admin, "Not admin");
        systemActive = !systemActive;
    }
}

contract Setup {
    Logger public logger;

    constructor() {
        logger = new Logger();
    }

    function isSolved() external view returns (bool) {
        return logger.systemActive() == false;
    }
}
