// SPDX-License-Identifier: MIT
pragma solidity ^0.8.23;

contract ChallengeA5 {
    mapping(address => uint256) public balances;
    mapping(address => uint256) public nonces;

    error Expired();
    error BadNonce();
    error BadSig();
    error InsufficientBalance();
    error BadSigLength();

    bytes32 public constant TYPEHASH =
        keccak256("SignedTransfer(address from,address to,uint256 amount,uint256 nonce,uint256 deadline,uint256 chainId,address verifyingContract)");

    event Executed(address indexed from, address indexed to, uint256 amount, uint256 nonce);

    function mintForTraining(address user, uint256 amount) public {
        balances[user] += amount;
    }

    // TODO (Player):
    // Build structHash with TYPEHASH + fields + block.chainid + address(this),
    // then wrap with EIP-191 prefix ("\x19Ethereum Signed Message:\n32").
    function digest(
        address from,
        address to,
        uint256 amount,
        uint256 nonce,
        uint256 deadline
    ) public view returns (bytes32) {
        // Placeholder: wrong on purpose
        return keccak256(abi.encode(from, to, amount, nonce, deadline));
    }

    // TODO (Player):
    // Parse signature (r,s,v), normalize v, return ecrecover(dgst, v, r, s)
    function recoverSigner(bytes32 dgst, bytes memory signature) public pure returns (address) {
        if (signature.length != 65) revert BadSigLength();

        // Placeholder: wrong on purpose
        (dgst, signature);
        return address(0);
    }

    // TODO (Player):
    // executeSignedTransfer must:
    // - check deadline
    // - check nonce == nonces[from]
    // - verify signature matches from
    // - check balance
    // - increment nonce BEFORE/with state update
    // - transfer balances
    function executeSignedTransfer(
        address from,
        address to,
        uint256 amount,
        uint256 nonce,
        uint256 deadline,
        bytes calldata signature
    ) external {
        // Placeholder: always revert so tests fail until implemented
        (from, to, amount, nonce, deadline, signature);
        revert BadSig();
    }
}
