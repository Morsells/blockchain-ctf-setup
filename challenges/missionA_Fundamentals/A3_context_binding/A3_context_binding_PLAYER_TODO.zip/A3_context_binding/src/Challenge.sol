// SPDX-License-Identifier: MIT
pragma solidity ^0.8.23;

contract ChallengeA3 {
    // Keep the same typehash as in the author version (tests expect digest changes across contracts/chains)
    bytes32 public constant TYPEHASH =
        keccak256("SignedTransfer(address from,address to,uint256 amount,uint256 nonce,uint256 deadline,uint256 chainId,address verifyingContract)");

    // TODO (Player):
    // structHash must include:
    // TYPEHASH, from, to, amount, nonce, deadline, block.chainid, address(this)
    function structHash(
        address from,
        address to,
        uint256 amount,
        uint256 nonce,
        uint256 deadline
    ) public view returns (bytes32) {
        // Placeholder: wrong on purpose
        return keccak256(abi.encode(TYPEHASH, from, to, amount, nonce, deadline));
    }

    // TODO (Player):
    // digest = keccak256("\x19Ethereum Signed Message:\n32" || structHash)
    function digest(
        address from,
        address to,
        uint256 amount,
        uint256 nonce,
        uint256 deadline
    ) public view returns (bytes32) {
        bytes32 sh = structHash(from, to, amount, nonce, deadline);

        // Placeholder: wrong on purpose
        return sh;
    }
}
