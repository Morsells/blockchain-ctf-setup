// SPDX-License-Identifier: MIT
pragma solidity ^0.8.23;

contract ChallengeA2 {
    error BadSigLength();

    // TODO (Player):
    // Parse r,s,v from signature (65 bytes) and return ecrecover(digest, v, r, s).
    // Normalize v: if (v < 27) v += 27;
    function recoverSigner(bytes32 digest, bytes memory signature) public pure returns (address) {
        if (signature.length != 65) revert BadSigLength();

        // Placeholder that compiles but fails tests:
        return address(0);
    }
}
