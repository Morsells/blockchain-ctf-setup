// SPDX-License-Identifier: MIT
pragma solidity ^0.8.23;

contract ChallengeA4 {
    mapping(address => uint256) public nonces;

    error Expired();
    error BadNonce();

    // TODO (Player):
    // - revert Expired if block.timestamp > deadline
    // - revert BadNonce if nonces[signer] != nonce
    // - then set nonces[signer] = nonce + 1
    function validateAndConsume(address signer, uint256 nonce, uint256 deadline) public {
        // Placeholder: compiles but fails tests (doesn't update / check)
        (signer, nonce, deadline);
    }
}
