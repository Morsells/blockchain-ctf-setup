// SPDX-License-Identifier: MIT
pragma solidity ^0.8.23;

contract ChallengeA1 {
    // TODO (Player):
    // Return keccak256(abi.encode(to, amount, nonce, deadline, chainId, verifyingContract))
    // Important: use abi.encode (NOT encodePacked).
    function hashMessage(
        address to,
        uint256 amount,
        uint256 nonce,
        uint256 deadline,
        uint256 chainId,
        address verifyingContract
    ) public pure returns (bytes32) {
        // Placeholder that compiles but fails tests:
        return bytes32(0);
    }
}
