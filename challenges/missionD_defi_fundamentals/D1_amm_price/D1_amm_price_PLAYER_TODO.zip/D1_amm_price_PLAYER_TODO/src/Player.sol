// SPDX-License-Identifier: MIT
pragma solidity ^0.8.23;

import "./Challenge.sol";

contract Player {
    function solve(SetupD1 setup) external {
        // TODO: Read reserves and AMM formulas.
        // TODO: Compute spot, quote, effective price, new spot, and needed input.
        // TODO: Call setup.submit(...) with correct values.
    }
}
