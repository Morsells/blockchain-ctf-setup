// SPDX-License-Identifier: MIT
pragma solidity ^0.8.23;

contract SimpleAMM {
    uint256 public constant BPS = 10_000;
    uint256 public constant FEE_BPS = 30;

    uint256 public reserveA;
    uint256 public reserveB;

    constructor(uint256 a, uint256 b) {
        reserveA = a;
        reserveB = b;
    }

    function spotPriceAinB() external view returns (uint256) {
        require(reserveA > 0, "no A");
        return (reserveB * 1e18) / reserveA;
    }

    function getAmountOut(uint256 amountIn, uint256 reserveIn, uint256 reserveOut) public pure returns (uint256) {
        require(amountIn > 0, "bad in");
        require(reserveIn > 0 && reserveOut > 0, "bad reserve");

        uint256 amountInWithFee = (amountIn * (BPS - FEE_BPS)) / BPS;
        return (amountInWithFee * reserveOut) / (reserveIn + amountInWithFee);
    }

    function getAmountIn(uint256 amountOut, uint256 reserveIn, uint256 reserveOut) public pure returns (uint256) {
        require(amountOut > 0, "bad out");
        require(reserveIn > 0 && reserveOut > amountOut, "bad reserve");

        uint256 numer = reserveIn * amountOut * BPS;
        uint256 denom = (reserveOut - amountOut) * (BPS - FEE_BPS);
        return (numer / denom) + 1;
    }

    function swapAforB(uint256 amountIn) external returns (uint256 out) {
        out = getAmountOut(amountIn, reserveA, reserveB);
        reserveA += amountIn;
        reserveB -= out;
    }

    function swapBforA(uint256 amountIn) external returns (uint256 out) {
        out = getAmountOut(amountIn, reserveB, reserveA);
        reserveB += amountIn;
        reserveA -= out;
    }
}

contract SetupD1 {
    SimpleAMM public amm;
    mapping(address => bool) private solved;

    constructor() {
        amm = new SimpleAMM(1_000 ether, 2_000 ether);
    }

    function submit(
        uint256 spot,
        uint256 quote,
        uint256 effectivePrice,
        uint256 newSpot,
        uint256 neededIn
    ) external {
        uint256 amountIn = 100 ether;

        require(spot == 2e18, "spot");

        uint256 out = amm.getAmountOut(amountIn, amm.reserveA(), amm.reserveB());
        uint256 amountInWithFee = (amountIn * (amm.BPS() - amm.FEE_BPS())) / amm.BPS();
        uint256 expectedOut = (amountInWithFee * amm.reserveB()) / (amm.reserveA() + amountInWithFee);

        require(quote == expectedOut, "quote");
        require(effectivePrice == (out * 1e18) / amountIn, "effective");
        require(effectivePrice < spot, "effective high");

        amm.swapAforB(amountIn);
        uint256 expectedNewSpot = (amm.reserveB() * 1e18) / amm.reserveA();
        require(newSpot == expectedNewSpot, "new spot");

        uint256 expectedNeededIn = amm.getAmountIn(out, amm.reserveA(), amm.reserveB());
        require(neededIn == expectedNeededIn, "needed in");
        require(neededIn >= amountIn, "needed < amountIn");

        solved[msg.sender] = true;
    }

    function isSolved(address player) external view returns (bool) {
        return solved[player];
    }
}
