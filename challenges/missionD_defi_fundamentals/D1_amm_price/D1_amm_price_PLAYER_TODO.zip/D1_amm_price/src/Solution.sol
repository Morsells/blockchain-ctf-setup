// SPDX-License-Identifier: MIT
pragma solidity ^0.8.23;

import "./SimpleAMM.sol";
import "./Challenge.sol";

contract SolutionD1 {
    // TODO: Spot-Preis berechnen
    function spotAinB(SimpleAMM /*amm*/) public view returns (uint256) {
        return 0;
    }

    // TODO: Output für A->B berechnen
    function quoteOutAtoB(SimpleAMM /*amm*/, uint256 /*amountIn*/) public view returns (uint256) {
        return 0;
    }

    // TODO: effektiven Preis berechnen
    function effectivePrice(SimpleAMM /*amm*/, uint256 /*amountIn*/) external view returns (uint256) {
        return 0;
    }

    // TODO: Swap + neuen Spot-Preis liefern
    function priceAfterSwapAforB(SimpleAMM /*amm*/, uint256 /*amountIn*/) external returns (uint256) {
        return 0;
    }
}
