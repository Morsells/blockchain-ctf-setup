// SPDX-License-Identifier: MIT
pragma solidity ^0.8.23;

import "./SimpleAMM.sol";
import "./LendingPool.sol";

contract SolutionD3 {
    // TODO: Preis manipulieren und zu viel leihen
    function manipulateAndBorrow(SimpleAMM /*amm*/, LendingPool /*pool*/) external {
        // TODO
    }
}
