// SPDX-License-Identifier: MIT
pragma solidity ^0.8.23;

import "forge-std/Test.sol";
import "../src/Challenge.sol";
import "../src/Player.sol";

contract D3CollateralLogicTest is Test {

    SetupD3 setup;
    Player player;

    function setUp() public {
        setup = new SetupD3();
        player = new Player();
    }

    function test_challenge() public {
        assertFalse(setup.isSolved(address(player)), "should not be solved yet");
        player.solve(setup);
        assertTrue(setup.isSolved(address(player)), "not solved");
        emit log_string("FLAG{missionD_D3_collateral_logic}");
    }
}
