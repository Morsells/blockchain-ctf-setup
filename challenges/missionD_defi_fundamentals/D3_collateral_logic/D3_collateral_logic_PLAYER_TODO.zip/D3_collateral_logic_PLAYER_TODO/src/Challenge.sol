// SPDX-License-Identifier: MIT
pragma solidity ^0.8.23;

contract SimpleAMM {
    uint256 public constant BPS = 10_000;
    uint256 public constant FEE_BPS = 30;

    uint256 public reserveA;
    uint256 public reserveB;

    constructor(uint256 a, uint256 b) {
        reserveA = a;
        reserveB = b;
    }

    function spotPriceAinB() external view returns (uint256) {
        require(reserveA > 0, "no A");
        return (reserveB * 1e18) / reserveA;
    }

    function getAmountOut(uint256 amountIn, uint256 reserveIn, uint256 reserveOut) public pure returns (uint256) {
        require(amountIn > 0, "bad in");
        require(reserveIn > 0 && reserveOut > 0, "bad reserve");

        uint256 amountInWithFee = (amountIn * (BPS - FEE_BPS)) / BPS;
        return (amountInWithFee * reserveOut) / (reserveIn + amountInWithFee);
    }

    function swapBforA(uint256 amountIn) external returns (uint256 out) {
        out = getAmountOut(amountIn, reserveB, reserveA);
        reserveB += amountIn;
        reserveA -= out;
    }
}

contract SimpleOracle {
    SimpleAMM public amm;

    constructor(SimpleAMM _amm) {
        amm = _amm;
    }

    function priceAinB() external view returns (uint256) {
        return amm.spotPriceAinB();
    }
}

contract LendingPool {
    SimpleOracle public oracle;
    uint256 public constant LTV_BPS = 5000;
    uint256 public constant BPS = 10_000;

    mapping(address => uint256) public collateralA;
    mapping(address => uint256) public debtB;
    uint256 public poolB;

    constructor(SimpleOracle _oracle, uint256 initialB) {
        oracle = _oracle;
        poolB = initialB;
    }

    function depositA(uint256 amount) external {
        require(amount > 0, "bad amount");
        collateralA[msg.sender] += amount;
    }

    function collateralValue(address user, uint256 price) public view returns (uint256) {
        return (collateralA[user] * price) / 1e18;
    }

    function maxBorrowAtPrice(address user, uint256 price) public view returns (uint256) {
        uint256 value = collateralValue(user, price);
        return (value * LTV_BPS) / BPS;
    }

    function maxBorrow(address user) public view returns (uint256) {
        return maxBorrowAtPrice(user, oracle.priceAinB());
    }

    function borrowB(uint256 amount) external {
        require(amount > 0, "bad amount");
        uint256 newDebt = debtB[msg.sender] + amount;
        require(maxBorrow(msg.sender) >= newDebt, "insufficient collateral");
        require(poolB >= amount, "no liquidity");
        poolB -= amount;
        debtB[msg.sender] = newDebt;
    }
}

contract SetupD3 {
    SimpleAMM public amm;
    SimpleOracle public oracle;
    LendingPool public pool;
    uint256 public initialPrice;

    constructor() {
        amm = new SimpleAMM(1_000 ether, 2_000 ether);
        oracle = new SimpleOracle(amm);
        pool = new LendingPool(oracle, 10_000 ether);
        initialPrice = amm.spotPriceAinB();
    }

    function isSolved(address player) external view returns (bool) {
        uint256 normalMax = pool.maxBorrowAtPrice(player, initialPrice);
        return pool.debtB(player) > normalMax && pool.poolB() < 10_000 ether;
    }
}
