// SPDX-License-Identifier: MIT
pragma solidity ^0.8.23;

import "./Challenge.sol";

contract Player {
    function solve(SetupD3 setup) external {
        // TODO: Deposit collateral in pool.
        // TODO: Manipulate oracle-dependent price through AMM.
        // TODO: Borrow enough B so setup.isSolved(address(this)) is true.
    }
}
