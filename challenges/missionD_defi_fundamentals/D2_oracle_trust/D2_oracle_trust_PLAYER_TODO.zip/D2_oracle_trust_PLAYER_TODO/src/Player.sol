// SPDX-License-Identifier: MIT
pragma solidity ^0.8.23;

import "./Challenge.sol";

contract Player {
    function solve(SetupD2 setup) external {
        // TODO: Manipulate AMM price via swaps.
        // TODO: Call oracle.update() after manipulation.
        // Goal: setup.isSolved(address(this)) must become true.
    }
}
