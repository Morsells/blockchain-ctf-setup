// SPDX-License-Identifier: MIT
pragma solidity ^0.8.23;

import "./SimpleAMM.sol";
import "./SimpleOracle.sol";

contract SolutionD2 {
    // TODO: Preis manipulieren und Oracle updaten
    function manipulateUp(SimpleAMM /*amm*/, SimpleOracle /*oracle*/, uint256 /*amountBIn*/) external {
        // TODO
    }
}
