// SPDX-License-Identifier: MIT
pragma solidity ^0.8.23;

import "./FlashLoanProvider.sol";
import "./SimpleAMM.sol";
import "./LendingPool.sol";
import "./TokenA.sol";
import "./TokenB.sol";

contract SolutionD4 is IFlashBorrower {
    // TODO: Flashloan nutzen und Profit behalten
    function run(
        FlashLoanProvider /*fl*/,
        SimpleAMM /*amm*/,
        LendingPool /*pool*/,
        TokenA /*a*/,
        TokenB /*b*/
    ) external {
        // TODO
    }

    function onFlashLoan(uint256 /*amount*/, uint256 /*fee*/, bytes calldata /*data*/)
        external
        returns (bytes32)
    {
        return keccak256("OK");
    }
}
